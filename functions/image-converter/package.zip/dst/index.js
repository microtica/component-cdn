"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const aws_sdk_1 = require("aws-sdk");
const child_process_1 = __importDefault(require("child_process"));
const fs_1 = __importDefault(require("fs"));
const querystring_1 = __importDefault(require("querystring"));
// interface Headers {
//     [key: string]: {
//         key: string;
//         value?: string | string[]
//     }[];
// }
const { bucketName } = process.env;
exports.handler = (event, context, callback) => {
    console.log(JSON.stringify(event));
    const request = event.Records[0].cf.request;
    const origin = request.origin.custom;
    const tmpPath = "/tmp/sourceImage";
    const targetPath = "/tmp/targetImage";
    const options = querystring_1.default.parse(request.querystring);
    const maxSize = 2000;
    const width = Math.min(parseInt(options.width) || maxSize, maxSize);
    const height = Math.min(parseInt(options.height) || maxSize, maxSize);
    // make sure input values are numbers
    if (Number.isNaN(width) || Number.isNaN(height)) {
        console.log("Invalid input");
        callback(null, {
            status: "400",
            statusDescription: "Invalid input"
        });
        return;
    }
    // dowload the file from the origin server
    const res = new aws_sdk_1.S3().getObject({
        Bucket: bucketName,
        Key: `${origin.path}${request.uri}`
    }).createReadStream();
    const writeStream = fs_1.default.createWriteStream(tmpPath);
    res
        .on("error", _ => {
        callback(null, {
            status: "500",
            statusDescription: "Error downloading the image"
        });
    })
        .pipe(writeStream);
    writeStream
        .on("finish", () => {
        console.log("image downloaded");
        try {
            // invoke ImageMagick to resize the image
            child_process_1.default.execSync(`convert ${tmpPath} -resize ${width}x${height}\\> -quality 80 ${targetPath}`);
        }
        catch (e) {
            console.log("ImageMagick error");
            console.log(e.stderr.toString());
            callback(null, {
                status: "500",
                statusDescription: "Error resizing image"
            });
            return;
        }
        const image = fs_1.default.readFileSync(targetPath).toString("base64");
        callback(null, {
            bodyEncoding: "base64",
            body: image,
            // headers: originHeaders,
            status: "200",
            statusDescription: "OK"
        });
    })
        .on("error", e => {
        console.log(e);
        callback(null, {
            status: "500",
            statusDescription: "Error writing the image to a file"
        });
    });
};
//# sourceMappingURL=index.js.map